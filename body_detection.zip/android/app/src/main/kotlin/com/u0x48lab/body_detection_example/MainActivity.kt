package com.u0x48lab.body_detection_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
